scp adam@10.11.96.191:/projects/pseudomonas_transcriptomics/storage/adam_out/pseudomonas_transcriptomics/Pseudomonas_aeruginosa_PAO1_107.nodesc.faa ./

